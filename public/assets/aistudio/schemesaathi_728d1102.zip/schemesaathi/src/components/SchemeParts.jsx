// Pieces used on both the results list and the detail page.
import { Link } from 'react-router-dom';
import { useI18n } from '../i18n/index.jsx';
import { describeCheck, headlineReason } from '../utils/describe.js';
import { isDemo } from '../data/index.js';
import { DemoTag, StatusBadge } from './Chrome.jsx';
import { IconDownload, IconBack, Seal } from './Icons.jsx';

const MARK = { pass: 'check', unknown: 'maybe', fail: 'cross' };

// "Why this result": every check with a tick, question mark or cross.
export function CheckList({ checks }) {
  const ctx = useI18n();
  return (
    <ul className="checks">
      {checks.map((c, i) => (
        <li key={i} className={`check check-${c.status}`}>
          <Seal kind={MARK[c.status]} size={22} />
          <span>{describeCheck(c, ctx)}</span>
        </li>
      ))}
    </ul>
  );
}

// One row in the results "ledger". Rows are rows (not identical cards) and the left edge shows status.
export function SchemeRow({ scheme, result, onDownload, busy }) {
  const ctx = useI18n();
  const { t, tx } = ctx;
  const demo = isDemo(scheme);
  return (
    <article className={`row row-${result.status}`}>
      <div className="row-main">
        <StatusBadge status={result.status} sample={demo} />
        <h3 className="row-title">{tx(scheme.name)}</h3>
        {demo && <DemoTag />}
        <p className="row-desc">{tx(scheme.description)}</p>
        <p className="row-reason">{headlineReason(result, ctx)}</p>
        <p className="row-meta">{t('rank.passed', { p: result.passed, t: result.total })}</p>
      </div>
      <div className="row-actions">
        <Link className="btn btn-solid" to={`/scheme/${scheme.id}`}>{t('btn.view')}</Link>
        <button type="button" className="btn btn-ghost" onClick={onDownload} disabled={busy}>
          <IconDownload />{busy ? t('btn.preparing') : t('btn.download')}
        </button>
      </div>
    </article>
  );
}

export function BackLink({ to, children }) {
  return <Link to={to} className="back-link"><IconBack />{children}</Link>;
}
