// Page chrome: Header (nav + language switcher), Footer, and a few tiny shared pieces.
import { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { LANGS, useI18n } from '../i18n/index.jsx';
import { IconClose, IconMenu, Logo, Seal } from './Icons.jsx';

export function Header() {
  const { t, lang, setLang } = useI18n();
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);
  return (
    <header className="site-header">
      <a className="skip" href="#main">{t('skip')}</a>
      <div className="wrap header-row">
        <Link to="/" className="brand" onClick={close}><Logo /><span>SchemeSaathi</span></Link>
        <button className="menu-btn" aria-expanded={open} aria-controls="site-nav" onClick={() => setOpen(!open)} aria-label={t('nav.menu')}>
          {open ? <IconClose /> : <IconMenu />}
        </button>
        <div id="site-nav" className={'nav-panel' + (open ? ' is-open' : '')}>
          <nav aria-label="Main">
            <NavLink to="/" end onClick={close}>{t('nav.home')}</NavLink>
            <NavLink to="/profile" onClick={close}>{t('nav.find')}</NavLink>
            <NavLink to="/results" onClick={close}>{t('nav.results')}</NavLink>
          </nav>
          <div className="lang" role="group" aria-label={t('lang.label')}>
            {LANGS.map((l) => (
              <button key={l.code} type="button" lang={l.code} aria-pressed={lang === l.code}
                className={lang === l.code ? 'is-on' : ''} onClick={() => { setLang(l.code); close(); }}>
                {l.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </header>
  );
}

export function Footer() {
  const { t } = useI18n();
  return (
    <footer className="site-footer">
      <div className="wrap"><p>{t('footer.disclaimer')}</p></div>
    </footer>
  );
}

// Visible on every fictional scheme.
export function DemoTag({ compact = false }) {
  const { t } = useI18n();
  return <span className={'demo-tag' + (compact ? ' is-compact' : '')} role="note">{compact ? t('demo.short') : t('demo.label')}</span>;
}

const SEAL = { eligible: 'check', maybe: 'maybe', not_eligible: 'cross' };
export function StatusBadge({ status, sample }) {
  const { t } = useI18n();
  return (
    <span className={`status status-${status}`}>
      <Seal kind={SEAL[status]} size={22} />
      <span>{t('status.' + status)}{sample && <small> ({t('status.sample')})</small>}</span>
    </span>
  );
}
