// The scheme "database". To use a bigger dataset later, replace schemes.json
// (same record shape) - nothing else in the app needs to change.
import raw from './schemes.json';

export const SCHEMES = raw.schemes;
export const getScheme = (id) => SCHEMES.find((s) => s.id === id);
export const isDemo = (scheme) => scheme.verificationStatus === 'demo';
