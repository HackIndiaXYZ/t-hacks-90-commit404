// Holds the form answers and the results. Saved in sessionStorage so a refresh keeps them
// (and it clears when the tab closes).
import { createContext, useCallback, useContext, useMemo, useState } from 'react';
import { matchSchemes, validateProfile } from '../eligibility/index.js';
import { SCHEMES } from '../data/index.js';
import { useI18n } from '../i18n/index.jsx';

// SAMPLE values from the brief. They are labelled as sample in the UI and are never used silently.
export const SAMPLE_FORM = {
  age: '45', state: 'Bihar', domicile: 'Bihar', domicileCertificate: '', occupation: 'farmer',
  income: '80000', incomeUnsure: false, gender: 'male', isStudent: '', ownsLand: '', hasDisabilityCertificate: '',
};
export const BLANK_FORM = {
  age: '', state: '', domicile: '', domicileCertificate: '', occupation: '',
  income: '', incomeUnsure: false, gender: '', isStudent: '', ownsLand: '', hasDisabilityCertificate: '',
};

// Convert form answers into the shape the engine expects.
export function toRaw(form, language) {
  return {
    language, age: form.age, state: form.state, domicile: form.domicile,
    domicileCertificate: form.domicileCertificate, occupation: form.occupation,
    annualIncome: form.incomeUnsure ? 'unsure' : form.income,
    gender: form.gender, isStudent: form.isStudent, ownsLand: form.ownsLand,
    hasDisabilityCertificate: form.hasDisabilityCertificate,
  };
}

const Ctx = createContext(null);
const KEY = 'ss-session';

function load() {
  try { return JSON.parse(sessionStorage.getItem(KEY)) || null; } catch { return null; }
}

export function ProfileProvider({ children }) {
  const { lang } = useI18n();
  const saved = useMemo(load, []);
  const [form, setForm] = useState(saved?.form || SAMPLE_FORM);
  const [isSample, setIsSample] = useState(saved ? saved.isSample : true);
  const [submitted, setSubmitted] = useState(saved?.submitted || null);
  const [fromText, setFromText] = useState([]); // field names filled from the user's sentence

  const persist = (next) => {
    try { sessionStorage.setItem(KEY, JSON.stringify(next)); } catch { /* ignore */ }
  };

  const setField = useCallback((name, value) => {
    setForm((f) => { const next = { ...f, [name]: value }; persist({ form: next, isSample, submitted }); return next; });
    setFromText((list) => list.filter((n) => n !== name)); // user edited it, so it counts as confirmed
  }, [isSample, submitted]);

  const clearSample = useCallback(() => {
    setForm(BLANK_FORM); setIsSample(false); setSubmitted(null); setFromText([]);
    persist({ form: BLANK_FORM, isSample: false, submitted: null });
  }, []);

  // Fields read from the user's sentence. We start from a BLANK form so no sample value sneaks in.
  const applyExtracted = useCallback((fields) => {
    const next = { ...BLANK_FORM };
    const used = [];
    for (const [k, v] of Object.entries(fields)) {
      if (k === 'annualIncome') { next.income = String(v); used.push('income'); }
      else if (k in next) { next[k] = String(v); used.push(k); }
    }
    setForm(next); setIsSample(false); setSubmitted(null); setFromText(used);
    persist({ form: next, isSample: false, submitted: null });
  }, []);

  const validate = useCallback(() => validateProfile(toRaw(form, lang)), [form, lang]);

  const submit = useCallback(() => {
    const check = validateProfile(toRaw(form, lang));
    if (!check.valid) return { ok: false, errors: check.errors };
    setSubmitted(form);
    persist({ form, isSample, submitted: form });
    return { ok: true };
  }, [form, lang, isSample]);

  // Results are recomputed from the submitted answers whenever needed.
  const analysis = useMemo(() => {
    if (!submitted) return null;
    try { return matchSchemes(toRaw(submitted, lang), SCHEMES); } catch { return null; }
  }, [submitted, lang]);

  const value = { form, setField, isSample, clearSample, applyExtracted, fromText, validate, submit, analysis };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useProfile = () => useContext(Ctx);
