import { Link } from 'react-router-dom';
import { useI18n } from '../i18n/index.jsx';
import HeroArt from '../components/HeroArt.jsx';

export default function Home() {
  const { t } = useI18n();
  const principles = [
    ['home.how.ai', 'home.how.ai.body'],
    ['home.how.rules', 'home.how.rules.body'],
    ['home.how.source', 'home.how.source.body'],
  ];
  return (
    <main id="main">
      <section className="hero">
        <div className="wrap hero-grid">
          <div className="hero-text">
            <h1>{t('hero.title')}</h1>
            <p className="lede">{t('hero.body')}</p>
            <div className="cta-row">
              <Link to="/profile" className="btn btn-primary btn-lg">{t('hero.cta')}</Link>
              <a href="#how" className="btn btn-link">{t('hero.cta2')}</a>
            </div>
          </div>
          <div className="hero-panel"><HeroArt /></div>
        </div>
      </section>

      <section id="how" className="section wrap">
        <h2 className="section-title">{t('home.how.title')}</h2>
        <div className="principles">
          {principles.map(([head, body]) => (
            <div className="principle" key={head}>
              <h3>{t(head)}</h3>
              <p>{t(body)}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="wrap section-tight">
        <aside className="demo-note">
          <h2>{t('home.demo.title')}</h2>
          <p>{t('home.demo.body')}</p>
        </aside>
      </section>
    </main>
  );
}
